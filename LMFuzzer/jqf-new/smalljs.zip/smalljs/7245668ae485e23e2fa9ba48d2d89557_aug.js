var v0 = 1;
if (v0 !== 1) {
    $ERROR('#1: \x0Bvar\x0Bx\x0B=\x0B1\x0B; x === 1. Actual: ' + v0);
}
var v0 = 1;
if (v0 !== 1) {
    $ERROR('#2: \x0Bvar\\vx\x0B=\\v1\x0B; x === 1. Actual: ' + v0);
}