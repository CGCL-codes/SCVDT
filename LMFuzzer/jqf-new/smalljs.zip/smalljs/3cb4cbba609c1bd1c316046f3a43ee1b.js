function f0(n) {
    var v0 = [];
    var v1 = /foo$/.test(v0) && v0.match(/(.*)foo$/);
}
for (var v2 = 500; v2 < 5000; v2 += 500)
    var v3 = f0(v2);