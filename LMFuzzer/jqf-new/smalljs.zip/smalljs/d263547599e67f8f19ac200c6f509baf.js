var v0 = /r/;
function f0() {
    v0[v0] = function () {
    };
}
for (var v1 = 0; v1 < 300000; v1++) {
    f0();
}