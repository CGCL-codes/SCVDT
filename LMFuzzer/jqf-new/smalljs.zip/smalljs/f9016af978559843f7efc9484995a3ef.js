var v0 = function () {
};
function f0(a = function () {
}) {
    print('Pass');
}
f0();