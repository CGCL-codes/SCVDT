var v0 = Math.sin(Math.PI / 2);
if (v0 === 1) {
    switch (v0) {
    case 1:
        break;
    default:
        throw 'FAIL';
    }
}