(function (a) {
    'use asm';
    var v0 = a.Infinity;
    function f0() {
        v0 - (2 ? 1 / 0 : +0);
    }
    return f0;
}(this)());