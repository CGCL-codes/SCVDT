(function () {
    var v0 = true ? 1 : 2;
}());