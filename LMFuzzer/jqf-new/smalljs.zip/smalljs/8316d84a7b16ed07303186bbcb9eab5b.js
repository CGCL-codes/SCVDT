for (var v0 = 0; v0 < 3; v0++) {
    var v1;
    function f0() {
    }
    with (this) {
    }
    v1;
    v1 = true;
}