class S extends Symbol {
}