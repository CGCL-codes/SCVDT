(function () {
    ((s = 17, y = s) => s)();
}());