var v0 = /o+/.test('abcdefg');
if (v0) {
    $ERROR('#1: /o+/.test("abcdefg") === false');
}