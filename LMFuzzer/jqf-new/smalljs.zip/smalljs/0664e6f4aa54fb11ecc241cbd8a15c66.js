(function (y) {
    for (var v0 = 0; v0 < 9; ++v0) {
        try {
            y ** y == a;
        } catch (e) {
        }
    }
}());