var v0 = new String('');
if (v0.slice(1, 0) !== '') {
    $ERROR('#1: __string = new String(""); __string.slice(1,0) === "". Actual: ' + v0.slice(1, 0));
}