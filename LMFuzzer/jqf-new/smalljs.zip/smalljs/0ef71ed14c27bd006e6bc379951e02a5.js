class C4 {
    *['constructor']() {
    }
}