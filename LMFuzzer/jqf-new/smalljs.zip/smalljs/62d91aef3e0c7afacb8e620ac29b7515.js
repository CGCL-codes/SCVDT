function f0() {
    NaN++;
    --NaN;
    Infinity--;
    ++Infinity;
    undefined++;
    --undefined;
    ++Math;
    Math--;
}
f0();