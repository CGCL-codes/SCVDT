var v0 = v1;
try {
    v1 = 12;
} finally {
    v1 = v0;
}