var v0 = new Object();
v0.push = function (i) {
    WScript.Echo('Pass');
};
v0.push(1);