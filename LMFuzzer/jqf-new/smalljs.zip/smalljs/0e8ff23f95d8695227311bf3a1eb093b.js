Object.prototype[3] = 3;
v0 = Array();
function f0() {
    for (v1 = 0; v1 < 9; v1++) {
        if (Object[v0++] != 0) {
        }
    }
}
f0();