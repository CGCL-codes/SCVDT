if (delete x !== true) {
    $ERROR('#1: delete x === true');
}