(function () {
    for (var v0 = 0; v0 < 8; v0++) {
        var v1 = v0;
    }
}());