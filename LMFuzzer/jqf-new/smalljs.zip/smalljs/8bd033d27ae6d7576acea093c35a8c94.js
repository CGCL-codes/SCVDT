var v0 = new Float64Array(2);
function f0(m) {
    v0[1] = m;
}
for (var v1 = 0; v1 < 20000; ++v1, Array('x'))
    f0(0);