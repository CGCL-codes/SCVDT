let v0 = 100;
let v1 = 200;
WScript.Echo(v0 == 100);
WScript.Echo(v1 == 200);
WScript.Echo('PASSED');