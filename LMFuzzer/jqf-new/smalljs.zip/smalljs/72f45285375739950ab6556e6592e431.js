for (; false;)
    function f0() {
    }