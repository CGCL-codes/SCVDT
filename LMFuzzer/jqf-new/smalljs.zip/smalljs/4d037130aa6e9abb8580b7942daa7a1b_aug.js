({
    foo: 1,
    get foo() {
    }
});