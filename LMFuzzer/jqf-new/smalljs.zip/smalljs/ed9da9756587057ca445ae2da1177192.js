function f0(x) {
    for (var v0 = 0; v0 < 100; v0++) {
        x.f === v0;
    }
}
f0({ f: 'three' });