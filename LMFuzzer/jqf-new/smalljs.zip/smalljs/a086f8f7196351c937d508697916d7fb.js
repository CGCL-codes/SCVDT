function f0(L) {
    var v0 = new Int8Array(8);
    v0[0] = 0;
}
for (var v1 = 0; v1 < 10; v1++) {
    f0(0);
}