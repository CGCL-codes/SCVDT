var v0 = {};
function f0() {
}
f0.prototype = {
    mSloppy() {
        super[v0] = 15;
    }
};
new f0().mSloppy();