'use strict';
var v0 = {};
({
    p: function () {
        v0.m;
    }
}.p());