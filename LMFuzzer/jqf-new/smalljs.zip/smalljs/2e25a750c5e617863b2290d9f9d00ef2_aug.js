({
    get foo() {
    },
    foo: 1
});