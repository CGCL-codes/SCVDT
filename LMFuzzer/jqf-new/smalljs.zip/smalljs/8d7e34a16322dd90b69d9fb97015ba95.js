if (!(Promise.prototype.catch instanceof Function)) {
    $ERROR('Expected Promise.prototype.catch to be a function');
}