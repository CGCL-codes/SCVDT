var v0 = false;
function f0() {
    v0 = 2;
    return 4 % v0;
}
f0();