var v0 = [];
Object.defineProperty(v0, 4, {
    configurable: true,
    enumerable: false,
    writable: false,
    value: undefined
});
for (var v1 = 0; v1 < 2; v1++)
    v0.length = 0;