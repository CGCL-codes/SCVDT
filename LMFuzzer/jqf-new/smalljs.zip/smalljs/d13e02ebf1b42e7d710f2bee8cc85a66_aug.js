(function () {
    var v0;
    for (v0 in [
            1,
            2,
            3,
            4
        ]) {
    }
}());