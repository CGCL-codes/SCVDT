(function () {
    var v0 = 1;
    for (var v1 = 0; v0.length < 1 && v1 < 3; v0.length++ + v1++) {
        v0 = 1;
    }
}());