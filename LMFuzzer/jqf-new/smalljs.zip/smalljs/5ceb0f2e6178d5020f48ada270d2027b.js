if (this.Worker) {
    v0 = '';
    var v1 = new Worker('');
    v1.postMessage(v0);
}