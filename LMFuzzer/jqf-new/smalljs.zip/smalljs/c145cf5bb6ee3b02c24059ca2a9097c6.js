class C {
    ['constructor']() {
    }
    constructor() {
    }
}