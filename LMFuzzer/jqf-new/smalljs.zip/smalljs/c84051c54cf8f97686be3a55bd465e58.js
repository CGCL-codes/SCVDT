var v0 = Function('eval = 42;');
v0();