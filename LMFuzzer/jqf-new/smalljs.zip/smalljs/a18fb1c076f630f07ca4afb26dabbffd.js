if (Array.prototype.join.prototype !== undefined) {
    $ERROR('#1: Array.prototype.join.prototype === undefined. Actual: ' + Array.prototype.join.prototype);
}