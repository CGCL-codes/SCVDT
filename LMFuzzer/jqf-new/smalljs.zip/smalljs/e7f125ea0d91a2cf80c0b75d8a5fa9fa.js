var v0 = '';
if (v0.length !== 0) {
    $ERROR('#1: var __str = ""; __str.length === 0. Actual: ' + v0);
}