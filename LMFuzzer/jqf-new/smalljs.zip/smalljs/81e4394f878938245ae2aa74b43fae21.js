var v0 = 1;
for (let v1 = 1; v1 < 3; v1++) {
    const v2 = 1;
    v2;
}
WScript.Echo('PASSED');