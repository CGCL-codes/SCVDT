if (Array.prototype.isPrototypeOf(Array()) !== true) {
    $ERROR('#1: Array.prototype.isPrototypeOf(Array()) === true. Actual: ' + Array.prototype.isPrototypeOf(Array()));
}