var v0 = {};
v0[Symbol.toStringTag] = 'test262';
assert.sameValue(Object.prototype.toString.call(v0), '[object test262]');