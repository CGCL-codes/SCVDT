if (Date.prototype.hasOwnProperty('setUTCFullYear') !== true) {
    $ERROR('#1: The Date.prototype has the property "setUTCFullYear"');
}