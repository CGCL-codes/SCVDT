function f0() {
    var {[arguments]: y} = {};
}
f0();