function f0(msg) {
}
v0 = function () {
};
v0.prototype = new Int32Array(1);
v1 = new v0();
function f1(v1) {
    with (this)
        for (var v2 in v1)
            f0(v1[v2]);
}
f1([]);