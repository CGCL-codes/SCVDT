function f0() {
    const v0 = 5;
    if (true) {
        WScript.Echo(v0);
    }
}
f0();