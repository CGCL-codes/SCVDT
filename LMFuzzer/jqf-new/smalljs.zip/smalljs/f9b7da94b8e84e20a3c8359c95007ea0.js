var v0 = 1;
WScript.Echo(v1);
{
    var v1 = function () {
        return 'bar';
    };
}
WScript.Echo(v1);
WScript.Echo('PASSED');