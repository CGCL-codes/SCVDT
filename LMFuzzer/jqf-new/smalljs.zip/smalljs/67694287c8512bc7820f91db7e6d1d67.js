var v0;
'x'.replace(/x/, function () {
    v0 = this;
});
WScript.Echo(v0 === this);