if (!Date.hasOwnProperty('UTC')) {
    $ERROR('#1: The Date constructor has the property "UTC"');
}