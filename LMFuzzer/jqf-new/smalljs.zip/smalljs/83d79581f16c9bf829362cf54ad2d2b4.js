if ('\x0Bstr\x0Bing\x0B' !== '\x0Bstr\x0Bing\x0B') {
    $ERROR('#1: "\x0Bstr\x0Bing\x0B" === "\\u000Bstr\\u000Bing\\u000B"');
}