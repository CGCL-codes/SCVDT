(function (stdlib, heap) {
    'use asm';
    function f0(v0) {
        v0 = v0 | 0;
        switch (12 << 10 % 1) {
        case -2:
        }
        ;
    }
}());