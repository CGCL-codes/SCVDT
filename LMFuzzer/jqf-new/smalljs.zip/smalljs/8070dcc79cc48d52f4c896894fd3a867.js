if (String('lego').charAt(undefined) !== 'l') {
    $ERROR('#1: String("lego").charAt(undefined) === "l". Actual: String("lego").charAt(undefined) ===' + String('lego').charAt(undefined));
}