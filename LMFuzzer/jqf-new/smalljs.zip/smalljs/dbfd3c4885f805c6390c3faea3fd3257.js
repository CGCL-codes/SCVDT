let v0 = 'bad';
v1 = 'bad';