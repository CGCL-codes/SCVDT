for (var v0 = 0; v0 < 1000; ++v0)
    new Int32Array(1000000);