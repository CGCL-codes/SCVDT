(function () {
    eval('        (function() {            var f = function(){                f            }        })()    ');
}());