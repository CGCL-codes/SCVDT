function f0() {
    v0 = 42;
}
;