Promise.resolve = () => 42;
Promise.all([1]);