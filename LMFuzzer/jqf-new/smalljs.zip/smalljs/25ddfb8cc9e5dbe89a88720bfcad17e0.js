var v0 = '//' + new Array('@').join('x');
eval('\'use strict\';' + 'var x = 23;' + 'var f = function bozo1() {' + '  return x;' + '};' + 'f;' + v0)();