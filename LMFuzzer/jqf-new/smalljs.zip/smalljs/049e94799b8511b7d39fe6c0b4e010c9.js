var v0;
function f0() {
    if (f1()) {
    }
}
function f1() {
    if (v0) {
        return true;
    }
}
f0();