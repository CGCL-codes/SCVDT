if (encodeURIComponent('#') !== '%23') {
    $ERROR('#1: unescapedURIComponentSet not containing "%23"');
}