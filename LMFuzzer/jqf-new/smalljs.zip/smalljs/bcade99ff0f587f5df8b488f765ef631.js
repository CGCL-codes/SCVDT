try {
    Object.create(function () {
    });
} catch (e) {
    assertTrue(false);
}