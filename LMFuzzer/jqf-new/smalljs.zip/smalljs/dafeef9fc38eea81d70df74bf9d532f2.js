v0 = 'string for triggering osr in __f_0';
for (var v1 = 0; v1 < 16; v1++)
    v0 = v0 + v0;
decodeURI(encodeURI(v0));