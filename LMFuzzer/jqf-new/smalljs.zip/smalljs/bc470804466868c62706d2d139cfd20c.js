if (String.prototype.match.prototype !== undefined) {
    $ERROR('#1: String.prototype.match.prototype === undefined. Actual: ' + String.prototype.match.prototype);
}