if (isFinite.prototype !== undefined) {
    $ERROR('#1: isFinite.prototype === undefined. Actual: ' + isFinite.prototype);
}