var v0 = new String('abc');
var v1 = v0[1];
v1[1];