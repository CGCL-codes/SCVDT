var v0 = new function f1() {
    return 1;
}();
if (typeof v0.constructor !== 'function')
    $ERROR('#1: typeof(x.constructor)!=="function"');