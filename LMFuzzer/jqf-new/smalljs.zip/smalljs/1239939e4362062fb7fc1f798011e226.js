if (new String('undefined').indexOf(v0) !== 0) {
    $ERROR('#1: var x; new String("undefined").indexOf(x) === 0. Actual: ' + new String('undefined').indexOf(v0));
}
var v0;