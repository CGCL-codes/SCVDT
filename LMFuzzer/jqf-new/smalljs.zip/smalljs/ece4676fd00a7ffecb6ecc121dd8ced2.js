'123456'.replace(/1(\d+)3/, '');
RegExp.lastMatch.toString();