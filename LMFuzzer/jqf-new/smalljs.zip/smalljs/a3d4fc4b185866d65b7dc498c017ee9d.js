if (true) {
} else
    function f0() {
    }