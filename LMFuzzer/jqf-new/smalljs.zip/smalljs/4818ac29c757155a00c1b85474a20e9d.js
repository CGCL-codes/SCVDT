for ({
        eval = 0
    } of [{}]);