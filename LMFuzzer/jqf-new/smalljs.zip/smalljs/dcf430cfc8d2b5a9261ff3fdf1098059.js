v0 = 0;
for (v1 = 0; v1 < 13; ++v1) {
    if (v1 == 7) {
        if (!v0) {
            this.__defineSetter__('x', Object.defineProperties);
        }
    }
}