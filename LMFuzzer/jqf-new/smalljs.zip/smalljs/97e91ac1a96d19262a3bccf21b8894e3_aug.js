try {
    gc(0, 'shrinking')({ x: 0 });
} catch (e) {
}
({
    x: 0,
    x: 0
}[{ x: 0 }]);