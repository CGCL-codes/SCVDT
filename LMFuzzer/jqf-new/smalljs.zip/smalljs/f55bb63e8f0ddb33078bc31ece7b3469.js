function f0() {
    'use strict';
}
for (var v0 in f0) {
    assert.notSameValue(v0, 'caller', 'tempIndex');
}