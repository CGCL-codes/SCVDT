function f0({}) {
}