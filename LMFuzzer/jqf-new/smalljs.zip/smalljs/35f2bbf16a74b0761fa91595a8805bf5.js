var v0;
for (var v1 = 0; v1 < 8; v1++) {
    Function.prototype();
}