var v0 = {
    set _11_1_5_1_fun(eval) {
    }
};