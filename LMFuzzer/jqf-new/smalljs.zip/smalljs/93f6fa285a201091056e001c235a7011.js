if (!this.hasOwnProperty('TypedObject'))
    throw new Error();
TypedObject.uint8.array(9e-10);