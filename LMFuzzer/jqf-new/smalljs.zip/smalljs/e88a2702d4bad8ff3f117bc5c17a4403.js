if (new Object().newProperty !== undefined) {
    $ERROR('#1: (new Object()).newProperty === undefined. Actual: ' + new Object().newProperty);
}