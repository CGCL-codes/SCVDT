for (false;;) {
    break;
}