var v0 = { w: 1 };
var v1 = { w: 2 };
v0.id = 1;
v0.name = 2;
v2 = v0.id;
v1.id = 3;
v3 = v1.name || 2;
WScript.Echo('ok');