(function () {
    var v0 = 1;
    var v1;
    v1 <<= 1;
    var v2 = 1 / (0 - v1);
    WScript.Echo('a = ' + v2);
}());