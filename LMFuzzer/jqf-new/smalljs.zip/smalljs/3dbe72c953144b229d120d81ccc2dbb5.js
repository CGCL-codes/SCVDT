var v0 = Function('\'use strict\'; for (var tempIndex in this) {assert.notSameValue(tempIndex, \'arguments\', \'tempIndex\');}');
v0.call(v0);