if (delete this.x !== true) {
    $ERROR('#1: delete this.x === true');
}