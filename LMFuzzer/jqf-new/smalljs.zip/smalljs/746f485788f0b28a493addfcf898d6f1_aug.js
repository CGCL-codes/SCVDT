assert.throws(SyntaxError, function () {
});