function f0() {
}
f0.bind();