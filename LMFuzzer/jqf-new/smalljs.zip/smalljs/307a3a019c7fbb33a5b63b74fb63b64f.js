var v0 = 'Window';
function f0(obj) {
    return obj instanceof Object || obj == window;
}