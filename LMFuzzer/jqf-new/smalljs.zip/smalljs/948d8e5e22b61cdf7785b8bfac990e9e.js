if (!Object.prototype.isPrototypeOf(Boolean.prototype)) {
    $ERROR('#1: Object prototype object is the prototype of Boolean prototype object');
}