if (!Error.prototype.hasOwnProperty('message')) {
    $ERROR('#1: Error.prototype.hasOwnProperty(\'message\') reurn true. Actual: ' + Error.prototype.hasOwnProperty('message'));
}