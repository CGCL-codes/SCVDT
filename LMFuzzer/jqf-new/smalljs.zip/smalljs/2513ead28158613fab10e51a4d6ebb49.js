function f0() {
    eval('this');
}
f0();
f0();