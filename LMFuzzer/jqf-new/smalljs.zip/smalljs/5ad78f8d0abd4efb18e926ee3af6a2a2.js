try {
    'foo';
} finally {
    throw 'bar';
}