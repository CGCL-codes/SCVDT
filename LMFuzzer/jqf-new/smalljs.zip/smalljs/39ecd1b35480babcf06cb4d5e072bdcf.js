if (Date.prototype.hasOwnProperty('getFullYear') !== true) {
    $ERROR('#1: The Date.prototype has the property "getFullYear"');
}