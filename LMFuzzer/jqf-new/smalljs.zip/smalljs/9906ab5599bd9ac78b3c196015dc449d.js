'use strict';
for (let v0 = function f() {
    }; !v0;);
for (var v0 = 0; v0 < 1000000; v0++);