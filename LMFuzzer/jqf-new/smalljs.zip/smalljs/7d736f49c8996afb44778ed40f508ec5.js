var v0 = eval;
v0('var arguments;');