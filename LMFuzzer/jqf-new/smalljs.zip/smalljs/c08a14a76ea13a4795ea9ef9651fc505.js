v0 = 1;
print(eval('eval(\'var x = 2\'); x;'));