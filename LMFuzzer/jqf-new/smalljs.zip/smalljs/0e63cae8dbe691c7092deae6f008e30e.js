function f0() {
    return new.target;
}
var v0 = new f0();