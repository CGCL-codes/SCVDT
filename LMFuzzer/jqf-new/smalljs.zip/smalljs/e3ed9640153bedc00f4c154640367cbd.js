class C {
    static ['constructor']() {
    }
}