var v0 = {
    p: 0.1,
    m: function () {
    }
};
v0.m();
for (var v1 = 0; v1 < 9; v1++)
    v0.p = 0.1;