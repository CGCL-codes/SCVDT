var v0 = function () {
    switch (1) {
    case 1:
        WScript.Echo(1);
        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
    }
};
v0();
v0();