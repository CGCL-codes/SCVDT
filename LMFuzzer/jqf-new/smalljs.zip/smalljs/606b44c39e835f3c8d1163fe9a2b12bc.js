var v0 = function f1() {
    return arguments;
}();
(function f2() {
    v0;
}());
WScript.Echo('pass');