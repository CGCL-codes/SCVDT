v0 = '';
function f0() {
    'use strict';
    var v1 = 4;
    var v2 = new Float32Array(v1);
    v2[0] = {};
}
f0();