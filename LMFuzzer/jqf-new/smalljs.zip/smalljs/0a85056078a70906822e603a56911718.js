var v0 = 100000;
for (var v1 = 0; v1 < v0; v1++) {
    if (v1 > v0)
        throw new Error();
}