function f0() {
    'use strict';
    let v0 = 1;
    for (let v0 = 0; false; false) {
    }
    return v0 === 1;
}
if (!f0())
    throw new Error('Test failed');