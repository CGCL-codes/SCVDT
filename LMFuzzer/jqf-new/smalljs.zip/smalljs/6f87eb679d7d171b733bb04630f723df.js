if (!Object.prototype.isPrototypeOf(Number.prototype)) {
    $ERROR('#1: Object prototype object is the prototype of Number prototype object');
}