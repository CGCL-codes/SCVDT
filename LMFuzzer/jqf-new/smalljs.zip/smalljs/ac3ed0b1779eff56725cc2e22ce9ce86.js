v0 = /x/;
v1 = [];
v2 = Object.defineProperty(v1, 'valueOf', {
    get: function () {
        +v2;
        for (var v3 = 0; v3 < 1; v3++) {
            v4 = v0.exec(0);
        }
    }
});
v1 + '';