if ('\fstr\fing\f' !== '\fstr\fing\f') {
    $ERROR('#1: "\fstr\fing\f" === "\\u000Cstr\\u000Cing\\u000C"');
}