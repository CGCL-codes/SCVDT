function f0(v0) {
    WScript.Echo(v0 + '');
}
WScript.LoadScriptFile('76628dad448abe258a67db08d36c9da7.js');
let v0;