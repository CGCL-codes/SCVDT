if (true)
    function f0() {
    }
else
    function f1() {
    }