var v0 = this;
v0 = Object.freeze(v0);