'use strict';
function f0() {
    return arguments.callee;
}