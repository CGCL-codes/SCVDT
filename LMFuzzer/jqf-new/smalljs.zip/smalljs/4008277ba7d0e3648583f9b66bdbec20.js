this.w = 0;
this.x = 1;
this.y = 2;
this.z = 3;