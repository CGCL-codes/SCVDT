function f0() {
    for (var v0 = 0; v0 < 50; v0++) {
        for (var v1 = 0; v1 < 0; v1++) {
            arguments, Array;
        }
    }
}
f0();