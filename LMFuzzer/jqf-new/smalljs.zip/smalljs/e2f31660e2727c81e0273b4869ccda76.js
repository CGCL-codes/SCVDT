if (Date.prototype.hasOwnProperty('getUTCDate') !== true) {
    $ERROR('#1: The Date.prototype has the property "getUTCDate"');
}