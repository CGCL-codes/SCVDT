'use strict';
'caller' in function () {
};