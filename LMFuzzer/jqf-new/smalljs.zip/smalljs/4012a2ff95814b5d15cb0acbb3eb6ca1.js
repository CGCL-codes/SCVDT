for (let v0 of []) {
    var v0;
}