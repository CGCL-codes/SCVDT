var v0 = /^xxx/.test('yyyyy');
if (v0) {
    $ERROR('#1: /^xxx/.test("yyyyy") === false');
}