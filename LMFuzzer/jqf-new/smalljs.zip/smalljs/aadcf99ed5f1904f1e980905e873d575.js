new RegExp('abc', 'y');
new RegExp('abc', 'gy');
new RegExp('abc', 'iy');
new RegExp('abc', 'my');
new RegExp('abc', 'uy');
new RegExp('abc', 'gimuy');