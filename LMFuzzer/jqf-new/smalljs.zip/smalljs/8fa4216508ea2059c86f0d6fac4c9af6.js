if ('report'.slice(function () {
    }()) !== 'report') {
    $ERROR('#1: "report".slice(function(){}()) === "report". Actual: ' + 'report'.slice(function () {
    }()));
}