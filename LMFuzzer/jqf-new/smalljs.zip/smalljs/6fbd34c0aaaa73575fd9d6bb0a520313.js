function f0() {
    'use strict';
    var v0 = new Function('a', 'eval(\'public = 1;\');');
    v0();
}
f0();