delete 0 .__proto__.valueOf;
eval('(function(){(0).valueOf();})')();