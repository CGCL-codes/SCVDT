for (i in ['']) {
}
function f0(...patterns) {
    patterns[i];
}
;
f0('');