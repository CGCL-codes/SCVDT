function f0(o) {
    var v0 = 'arguments';
    for (var v1 = 0; v1 < 10; v1++) {
        f0[v0];
    }
}
f0({});
f0({});
f0({});
f0({});