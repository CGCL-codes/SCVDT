if (Date.prototype.hasOwnProperty('getUTCSeconds') !== true) {
    $ERROR('#1: The Date.prototype has the property "getUTCSeconds"');
}