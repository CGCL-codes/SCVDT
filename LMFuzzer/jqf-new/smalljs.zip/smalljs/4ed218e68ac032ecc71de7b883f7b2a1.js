if ('퓛'.localeCompare('퓛') != 0) {
    print(54491);
}
print('PASS');