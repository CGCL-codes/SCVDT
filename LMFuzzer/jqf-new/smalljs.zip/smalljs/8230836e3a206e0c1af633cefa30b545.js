{
    var v0;
    function v0() {
    }
}