if (!this.hasOwnProperty('TypedObject'))
    throw new Error('type too large');
var v0 = TypedObject.uint8.array(2147483647).array(5);
var v1 = new v0();
var v2 = v1[0];