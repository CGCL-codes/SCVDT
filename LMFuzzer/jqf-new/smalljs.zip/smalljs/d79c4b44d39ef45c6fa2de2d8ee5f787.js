var v0 = Function('return this')();
if (v0.count !== 9)
    throw new Error(`bad value ${ v0.count }`);
v0.count = 10;