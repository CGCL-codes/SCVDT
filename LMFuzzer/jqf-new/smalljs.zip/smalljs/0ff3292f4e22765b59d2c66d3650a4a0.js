if (typeof oomTest === 'function')
    oomTest(Function(`new Promise(res=>res)`));