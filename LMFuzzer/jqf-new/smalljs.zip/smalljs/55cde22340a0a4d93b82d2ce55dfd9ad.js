Array.prototype[10000000] = 1;
Array(1000).join();