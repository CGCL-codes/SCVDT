if (Array.prototype.pop.length !== 0) {
    $ERROR('#1: Array.prototype.pop.length === 0. Actual: ' + Array.prototype.pop.length);
}