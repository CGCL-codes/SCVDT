function f0() {
    {
        let v0 = 1;
        v0++;
    }
    return 0;
}
f0();
WScript.Echo('PASSED');