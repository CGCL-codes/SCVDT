for (var v0 in Error.prototype) {
    assert.notSameValue(v0, 'message', 'i');
}