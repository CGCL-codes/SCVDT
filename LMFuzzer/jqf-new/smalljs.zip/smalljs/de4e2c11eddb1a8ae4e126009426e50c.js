var v0 = Symbol();
var v1 = {};
v1[v0] = 2;
v1[''] = 3;
Object.getOwnPropertySymbols(v1);