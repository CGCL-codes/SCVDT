function f0(arguments) {
}
;