var v0 = new Proxy({}, {
    getOwnPropertyDescriptor: function () {
        throw v0;
    }
});
Object.prototype.__lookupGetter__.call(v0, 'q');