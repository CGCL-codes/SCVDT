for (var v0 in {})
    label1:
        label2:
            function f0() {
            }