if (true) {
    {
        let v0;
    }
} else {
}