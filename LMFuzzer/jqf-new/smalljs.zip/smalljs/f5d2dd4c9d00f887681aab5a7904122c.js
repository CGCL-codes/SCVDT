function f0() {
    var v0 = undefined ? 1 : 4294967295;
    print(false || v0);
}
f0();