for (; false;)
    label1:
        label2:
            function f0() {
            }