if (Array.prototype.splice.length !== 2) {
    $ERROR('#1: Array.prototype.splice.length === 2. Actual: ' + Array.prototype.splice.length);
}