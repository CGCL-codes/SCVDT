var v0 = new Array();
v0[0] = '';
f0();
function f0() {
    for (i in v0) {
        v1 = v0[i];
        v2 = f0(v1);
    }
}