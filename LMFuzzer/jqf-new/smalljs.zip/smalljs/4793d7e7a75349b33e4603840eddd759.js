var v0 = {
    get finally() {
        if (v0[v1[v2]] !== v2) {
        }
    }
};
var v1 = ['finally'];
for (var v2 = 0; v2 < v1.length; v2++) {
    if (v0[v1[v2]] !== v2) {
    }
}