var v0 = 4;
Object.defineProperty(this, 'x', { writable: false });
v0 = 3;
WScript.Echo(v0);
var v0 = 5;
WScript.Echo(v0);