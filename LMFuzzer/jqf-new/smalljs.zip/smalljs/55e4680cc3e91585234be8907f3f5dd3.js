(function () {
    /(오)/;
}());
print('pass');