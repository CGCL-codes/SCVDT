if (Date.prototype.hasOwnProperty('setMilliseconds') !== true) {
    $ERROR('#1: The Date.prototype has the property "setMilliseconds"');
}