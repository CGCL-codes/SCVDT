v0 = { value: '' };
v1 = 0;
for (var v2 = 0; v2 < 20; v2++) {
    Object.defineProperty(this, 'z', v0);
    v1 = 1;
}