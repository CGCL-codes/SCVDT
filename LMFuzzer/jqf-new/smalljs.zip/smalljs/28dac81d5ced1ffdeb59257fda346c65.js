for (var v0 = 0; v0 < 9; v0++) {
    Math.abs(-2147483648);
}