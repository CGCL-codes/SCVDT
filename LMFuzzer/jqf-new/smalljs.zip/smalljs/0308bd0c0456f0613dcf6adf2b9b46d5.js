'use strict';
var v0 = {
    get '%3'() {
    }
};
v0['%3'] = 10;