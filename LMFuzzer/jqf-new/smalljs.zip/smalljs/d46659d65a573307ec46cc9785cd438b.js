(function () {
    for (let v0 in [0]) {
        return;
    }
}());