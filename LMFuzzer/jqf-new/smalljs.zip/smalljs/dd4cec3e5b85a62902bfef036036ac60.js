var v0;
for (let v1 = 0; v1 < 8; v1++) {
    Function.prototype();
}