if (Date.prototype.hasOwnProperty('constructor') !== true) {
    $ERROR('#1: The Date.prototype has the property "constructor"');
}