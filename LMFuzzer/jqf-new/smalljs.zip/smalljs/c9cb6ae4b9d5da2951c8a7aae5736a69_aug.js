var v0 = 1;
if (v0 !== 1) {
    $ERROR('#1: \fvar\fx\f=\f1\f; x === 1. Actual: ' + v0);
}
var v0 = 1;
if (v0 !== 1) {
    $ERROR('#2: \fvar\\fx\f=\\f1\f; x === 1. Actual: ' + v0);
}