if (true)
    function f0() {
    }
else ;