function f0([,]) {
}
function f1([, ,]) {
}