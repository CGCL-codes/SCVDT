function f0(x, y) {
}
for (var v0 = 0; v0 < 5; v0++)
    f0.call('');