try {
} catch (e) {
    WScript.Echo(e);
}