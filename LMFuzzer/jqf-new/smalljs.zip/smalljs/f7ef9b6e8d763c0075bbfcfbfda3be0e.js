v0 = new Array();
v1 = encodeURIComponent(v0);
v2 = isFinite();
v3 = new Array(v2);
v4 = v3.includes(v1);