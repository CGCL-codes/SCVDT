new Array(100).sort(function (a, b) {
    return a - b;
});