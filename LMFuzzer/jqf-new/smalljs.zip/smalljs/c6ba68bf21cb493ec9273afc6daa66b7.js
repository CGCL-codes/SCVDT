switch (true) {
case true:
    const v0 = 1;
}