if (Number.prototype.hasOwnProperty('toExponential') !== true) {
    $ERROR('#1: The Number prototype object has the property toExponential');
}