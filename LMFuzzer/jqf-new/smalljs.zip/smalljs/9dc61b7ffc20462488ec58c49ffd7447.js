function f0(a) {
    return { 0.1: a };
}
f0();