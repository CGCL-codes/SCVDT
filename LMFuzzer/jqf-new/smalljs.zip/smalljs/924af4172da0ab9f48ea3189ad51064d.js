function f0() {
    switch (f1) {
    case v0:
        function f1() {
        }
    }
}
var v0;
f0();