if (Function.prototype.isPrototypeOf(Array) !== true) {
    $ERROR('#1: Function.prototype.isPrototypeOf(Array) === true. Actual: ' + Function.prototype.isPrototypeOf(Array));
}