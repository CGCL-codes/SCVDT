var v0 = {};
v0[v0.p] = 2;