f0({
    length: 4,
    company: 'netscape',
    year: 2000,
    0: 'zero'
});
function f0(object) {
    v0 = new Array();
    for (v0[v0.length] in object) {
        object[1];
    }
}