if (String.prototype.search.prototype !== undefined) {
    $ERROR('#1: String.prototype.search.prototype === undefined. Actual: ' + String.prototype.search.prototype);
}