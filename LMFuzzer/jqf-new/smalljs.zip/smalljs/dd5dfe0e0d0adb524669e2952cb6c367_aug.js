function f0() {
    for (var v0 = 0; v0 < 12; v0++) {
        try {
            void v1;
        } catch (e) {
        }
    }
}
f0();
let v1;