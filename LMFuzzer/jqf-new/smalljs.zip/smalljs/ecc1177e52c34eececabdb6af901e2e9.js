for (let v0 in []) {
    t(v0 !== v0);
}