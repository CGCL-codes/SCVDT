var v0 = [1];
v0.foo = 'bla';
delete v0.foo;
v0[0] = 1.5;
var v1 = [];
v1.foo = 'bla';
delete v1.foo;