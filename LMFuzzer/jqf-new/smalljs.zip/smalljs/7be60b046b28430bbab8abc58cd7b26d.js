function f0() {
    for (var v0 = 1; v0 < 1; v0++) {
        for (var v1 = 1; v1 < 1; v1++) {
        }
    }
}
f0();