if (typeof Promise.resolve !== 'function') {
    $ERROR('Expected Promise.resolve to be a function');
}