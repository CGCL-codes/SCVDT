var v0 = new Object();
for (x in +v0) {
}
for (a[+v0] in v0) {
}
try {
    v0[+v0](1, 2, 3);
} catch (e) {
}