if ('abcd'.indexOf('abcdab') !== -1) {
    $ERROR('#1: "abcd".indexOf("abcdab")===-1. Actual: ' + 'abcd'.indexOf('abcdab'));
}