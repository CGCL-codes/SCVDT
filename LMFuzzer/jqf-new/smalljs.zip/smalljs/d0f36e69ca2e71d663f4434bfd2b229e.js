function f0(f1 = 0) {
    {
        function f1() {
            return 'g';
        }
    }
}
f0();