try {
    eval('v>>([]=x)');
} catch (e) {
}