function f0(t) {
    try {
        var v0 = arguments;
        v0.setTime;
    } catch (err) {
    }
}
f0();