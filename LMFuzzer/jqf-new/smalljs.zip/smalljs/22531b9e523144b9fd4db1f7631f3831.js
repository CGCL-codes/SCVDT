'use strict';
'arguments' in function () {
};