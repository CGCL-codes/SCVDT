Object.defineProperty(this, 'x', {
    set: function () {
    }
});
Object.freeze(this);
'use strict';
v0 = 20;