if (typeof x !== 'undefined') {
    $ERROR('#1: typeof (x) === "undefined". Actual: ' + typeof x);
}