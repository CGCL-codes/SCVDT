var v0 = new Function('\'use strict\'; for (var tempIndex in this) {assert.notSameValue(tempIndex, \'arguments\', \'tempIndex\');}');
v0.call(v0);