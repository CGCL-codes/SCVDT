function f0(x) {
    x >>> 3.14;
    x >>> true;
    x >>> 0 / 0;
    x >>> 100;
    x >>> -10;
    x >>> 1 / 0;
    x >>> void 0;
}
f0(10);