var v0 = new Error();
function f0() {
    var v1 = new Float32Array(1);
    for (var v2 in v0) {
    }
    var v3 = v1[0];
    switch (v3) {
    }
}
f0();