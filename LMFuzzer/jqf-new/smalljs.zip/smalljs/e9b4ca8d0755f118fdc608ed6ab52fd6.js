(function (a) {
    var v0 = a;
    v0 = 1.1 !== true ? a : a;
}(1));