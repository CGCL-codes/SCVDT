if (decodeURIComponent.length !== 1) {
    $ERROR('#1: decodeURIComponent.length === 1. Actual: ' + decodeURIComponent.length);
}