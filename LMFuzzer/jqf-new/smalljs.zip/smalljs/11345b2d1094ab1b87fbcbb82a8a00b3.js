(function (_ = function () {
}) {
});