var v0 = eval;
v0('eval = 42;');