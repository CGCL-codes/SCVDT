for (var v0 = 0; v0 <= 256; v0++) {
}
function f0() {
    v0 = 'luft';
    v0 += ++v0;
}
f0();