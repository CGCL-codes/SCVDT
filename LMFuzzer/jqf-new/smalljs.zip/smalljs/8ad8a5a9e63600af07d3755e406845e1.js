try {
    (function () {
        eval('gc().l()');
    }());
} catch (e) {
}