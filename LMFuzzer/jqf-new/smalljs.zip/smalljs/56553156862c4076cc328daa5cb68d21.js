for (let v0 in []) {
    v0 << v0++;
}