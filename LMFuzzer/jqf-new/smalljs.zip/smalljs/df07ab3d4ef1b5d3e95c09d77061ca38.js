var v0 = 0;
function f0() {
    return new Array(-1);
}
for (var v1 = 0; v1 < 61; ++v1) {
    try {
        f0();
        ++v0;
    } catch (e) {
    }
}