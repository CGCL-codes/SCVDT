var v0 = new RegExp();
var v1 = delete RegExp.length;