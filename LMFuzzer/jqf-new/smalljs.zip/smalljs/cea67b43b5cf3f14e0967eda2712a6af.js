function f0() {
    var v0 = 3;
    return v0 === 3;
}
if (!f0())
    throw new Error('Test failed');