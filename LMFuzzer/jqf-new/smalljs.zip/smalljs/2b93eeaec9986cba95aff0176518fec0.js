if (Date.prototype.hasOwnProperty('toDateString') !== true) {
    $ERROR('#1: The Date.prototype has the property "toDateString"');
}