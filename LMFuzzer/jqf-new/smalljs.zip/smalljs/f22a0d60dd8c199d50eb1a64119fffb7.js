var v0 = Function('return this;')();
function f0() {
    return v0;
}