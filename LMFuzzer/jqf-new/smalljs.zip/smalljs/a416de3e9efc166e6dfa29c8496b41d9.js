var v0 = RegExp('');
var v1 = '';
v1 += ''.replace(v0, Function('x'));
for (var v2 = 0; v2 < 5; v2++) {
    v1 += ''.replace(v0, this);
}