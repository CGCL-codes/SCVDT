var v0 = +0;
if (Math.exp(v0) !== 1) {
    $ERROR('#1: \'var x = +0; Math.exp(x) !== 1\'');
}