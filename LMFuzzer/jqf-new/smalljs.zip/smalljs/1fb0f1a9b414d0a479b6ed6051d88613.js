if (!Object.hasOwnProperty('prototype')) {
    $ERROR('#1: The Object constructor has the property "prototype"');
}