'use strict';
var v0 = new Function('eval = 42;');
v0();