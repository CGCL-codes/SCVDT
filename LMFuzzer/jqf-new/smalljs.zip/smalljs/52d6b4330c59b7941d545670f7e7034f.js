(function () {
    function f0() {
        const v0 = 42;
    }
}());