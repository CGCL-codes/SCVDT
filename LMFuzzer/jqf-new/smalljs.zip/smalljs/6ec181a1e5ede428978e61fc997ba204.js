if (Array.prototype.push.length !== 1) {
    $ERROR('#1: Array.prototype.push.length === 1. Actual: ' + Array.prototype.push.length);
}