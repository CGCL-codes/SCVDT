'use strict';
var v0 = 0;
var v1 = 9;
for (var v2 = 0; v2 < v1; v0++, v2++) {
    v0 = 0;
}
print('done');