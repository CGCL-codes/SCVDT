function f0() {
    var v0;
}
f0();