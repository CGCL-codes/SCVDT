function f0() {
    '' < '';
}