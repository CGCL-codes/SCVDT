if (Intl.PluralRules.prototype.constructor !== Intl.PluralRules) {
    $ERROR('Intl.PluralRules.prototype.constructor is not the same as ' + 'Intl.PluralRules');
}