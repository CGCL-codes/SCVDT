'use strict';
function f0() {
    eval();
}
;
eval('delete this;');