v0 = function () {
};
const v1 = 5;
WScript.Echo(v1);