(function () {
    try {
    } finally {
        {
            let v0;
            return;
        }
    }
}());