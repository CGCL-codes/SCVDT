if (RegExp.prototype.test.prototype !== undefined) {
    $ERROR('#1: RegExp.prototype.test.prototype === undefined. Actual: ' + RegExp.prototype.test.prototype);
}