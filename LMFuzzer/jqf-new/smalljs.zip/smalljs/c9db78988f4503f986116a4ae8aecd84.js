function f0() {
    try {
        var v0 = undefined;
    } catch (f0) {
    }
    while (v0)
        continue;
}
for (var v1 = 0; v1 < 20; v1++)
    f0();