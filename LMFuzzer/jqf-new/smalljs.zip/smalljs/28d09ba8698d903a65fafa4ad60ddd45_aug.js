'use strict';
(function (a) {
    return arguments[a];
}());
WScript.Echo('PASS');