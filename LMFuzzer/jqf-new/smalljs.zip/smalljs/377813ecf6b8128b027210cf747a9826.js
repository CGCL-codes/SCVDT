var v0 = { a: 1 };
for (let in v0) {
}