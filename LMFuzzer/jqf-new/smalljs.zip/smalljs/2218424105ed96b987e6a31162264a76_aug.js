try {
} catch (e) {
}