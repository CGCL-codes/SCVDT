if (Date.prototype.hasOwnProperty('setUTCMinutes') !== true) {
    $ERROR('#1: The Date.prototype has the property "setUTCMinutes"');
}