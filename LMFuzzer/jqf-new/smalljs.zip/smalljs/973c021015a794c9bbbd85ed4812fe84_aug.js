Array.prototype.__proto__ = Function.prototype;
var v0 = [
    1,
    2,
    3
];
v0[0];
[].__proto__.foo = true;
[];