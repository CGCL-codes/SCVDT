(function () {
}.hasOwnProperty('arguments'));