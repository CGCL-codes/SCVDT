for (var v0 = 0; v0 < 200; v0++) {
    (function* get(undefined, ...get) {
        g.apply(this, arguments);
    }());
}