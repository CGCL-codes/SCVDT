(function f(i) {
    for (; false;) {
    }
    ;
    if (i)
        f(i - 1);
}(50));