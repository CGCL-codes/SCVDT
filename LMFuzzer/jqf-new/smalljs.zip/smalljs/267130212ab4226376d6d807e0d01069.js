try {
    throw 'foo';
} catch (e) {
    throw 'bar';
} finally {
    'baz';
}