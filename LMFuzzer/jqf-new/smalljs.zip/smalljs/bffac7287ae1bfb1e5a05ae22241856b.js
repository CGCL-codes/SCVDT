var v0 = Math.E;
Math.E = 1;
if (Math.E !== v0) {
    $ERROR('#1: __e = Math.E; Math.E = 1; Math.E === __e. Actual: ' + Math.E);
}