var v0 = [];
Object.defineProperty(v0, 'length', { writable: false });
Object.defineProperty(v0, 'length', { value: 0 });