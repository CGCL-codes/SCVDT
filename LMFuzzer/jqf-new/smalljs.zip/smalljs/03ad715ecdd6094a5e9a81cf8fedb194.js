if ('abcd'.indexOf('abcdab', 0) !== -1) {
    $ERROR('#1: "abcd".indexOf("abcdab",0)===-1. Actual: ' + 'abcd'.indexOf('abcdab', 0));
}