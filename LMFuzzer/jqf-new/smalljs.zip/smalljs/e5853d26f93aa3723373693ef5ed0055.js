!{
    async foo(arguments) {
    }
};