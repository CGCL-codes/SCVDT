if (Date.prototype.hasOwnProperty('getMilliseconds') !== true) {
    $ERROR('#1: The Date.prototype has the property "getMilliseconds"');
}