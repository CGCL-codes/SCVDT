function* f0(a) {
}
function* f1(a, b) {
}