function f0() {
}