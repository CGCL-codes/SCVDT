if (Array.prototype.toLocaleString.length !== 0) {
    $ERROR('#1: Array.prototype.toLocaleString.length === 0. Actual: ' + Array.prototype.toLocaleString.length);
}