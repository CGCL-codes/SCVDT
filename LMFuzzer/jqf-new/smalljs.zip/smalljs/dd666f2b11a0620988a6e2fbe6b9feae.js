try {
    {
        function f0() {
        }
    }
    v0 = 0 .__proto__;
    function f1(v0) {
        v0._('', function () {
        });
    }
    f1(v0);
} catch (e) {
}