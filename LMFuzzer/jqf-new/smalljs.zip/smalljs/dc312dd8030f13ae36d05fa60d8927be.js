for (var v0 = 0; v0 < 5000; ++v0)
    new Int32Array(10000);